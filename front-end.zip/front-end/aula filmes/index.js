class filme {
    constructor(titulo,episodios, nota, streaming, opniao){
        this.titulo = titulo
        this.episodios = episodios
        this.nota = nota
        this.streaming = streaming
        this.opniao = opniao
    }
}

const formulario = document.getElementById('filmeForm')
formulario.addEventListener('submit', function(evento){

    evento.preventDefault()

    const titulo = document.getElementById('titulo')
    const episodios = document.getElementById('episodios')
    const nota = document.getElementById('nota')
    const streaming = document.getElementById('streaming')
    const opniao = document.getElementById('opniao')

    const Filme = new filme (titulo.value, episodios.value, nota.value, streaming.value, opniao.value )

    console.log(Filme)
});

