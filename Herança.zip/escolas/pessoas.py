
class Pessoas:
    def __init__(self, nome, cpf, nascimento, telefone):
        self.nome = nome
        self.cpf = cpf
        self.nascimento = nascimento
        self.telefone = telefone
