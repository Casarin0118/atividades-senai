class Animais:
    def __init__(self, raca,cor, idade, nome):
        self.raca = raca
        self.cor = cor
        self.idade = idade
        self.nome = nome


