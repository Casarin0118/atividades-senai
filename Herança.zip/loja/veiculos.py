
class Veiculos:
    def __init__(self, rodas, assentos, valor, km, potencia, ano):
        self.rodas = rodas
        self.assentos = assentos
        self.valor = valor
        self.km = km
        self.potencia = potencia
        self. ano = ano